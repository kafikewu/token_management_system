from django.apps import AppConfig


class SystemadminsConfig(AppConfig):
    name = 'systemadmins'
