from django.apps import AppConfig


class LoginandregistationConfig(AppConfig):
    name = 'loginandregistation'
